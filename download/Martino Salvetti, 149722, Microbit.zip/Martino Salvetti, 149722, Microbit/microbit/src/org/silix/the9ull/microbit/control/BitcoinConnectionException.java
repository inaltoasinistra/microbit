package org.silix.the9ull.microbit.control;

public class BitcoinConnectionException extends Exception {

}
