Microbi(t)
========

Starting Bitcoin (test mode)
----------------------

bitcoin-qt -testnet -server


Connect to MySql db
-------------------

mysql --user=root --password=ddww4l microbit

